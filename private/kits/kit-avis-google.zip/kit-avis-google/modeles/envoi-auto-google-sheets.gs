/**
 * ENVOI AUTOMATIQUE DES DEUX MAILS — Kit Avis Google (Mel Nourdi)
 * Gratuit, avec un compte Google (Gmail gratuit ou Workspace) : un Google Sheets + ce script.
 *   Mail 1 : la demande d'avis, 24 h après chaque rendez-vous marqué « Fait ».
 *   Mail 2 : le merci avec la roue cadeau, 3 jours après. Les deux ne se mélangent jamais.
 *
 * Onglet « RDV » du Google Sheets, ligne 1 = ces en-têtes exacts :
 *   Prénom | Email | Date RDV | Statut | Avis envoyé le | Roue envoyée le | Cadeau | Code cadeau | Valable jusqu'au | Ne plus écrire
 * - Cadeau / Code cadeau / Valable jusqu'au : remplis par le script quand la roue part. Le client montre ce code
 *   à sa prochaine visite : tu le retrouves dans le tableau (Ctrl+F). Pas besoin de logiciel.
 * - Date RDV : date et heure du rendez-vous (format date de Google Sheets).
 * - Statut : écrire « Fait » quand le rendez-vous a bien eu lieu (rien ne part pour un lapin ou une annulation).
 * - Avis envoyé le / Roue envoyée le : remplis par le script. Ne pas toucher.
 * - Ne plus écrire : mettre « oui » si le client ne veut plus de mails.
 *
 * L'assistante remplace les SUJETS, EXPEDITEUR et les deux HTML (dans le style de la personne).
 */

const EXPEDITEUR = "Studio Lumière";          // nom affiché
const MAX_PAR_PASSAGE = 40;                   // garde une marge sous la limite d'envoi de Gmail
const ID_IMAGE_ROUE = "";                      // identifiant Google Drive de roue-mail.gif (dans le mail : <img src="cid:roue">)
const LIEN_ROUE = "";                          // adresse de ta roue en ligne (page publiée)
const CADEAUX = ["10 € offerts", "5 € offerts", "Un soin offert", "-10 % sur ta séance"]; // MÊME ordre que dans la roue
const PREFIXE_CODE = "LUM";                    // 2 à 4 lettres
const VALIDITE_JOURS = 60;

const MAILS = [
  { colonne: "Avis envoyé le",  delaiHeures: 24, sujet: "{{prenom}}, comment s'est passé ton rendez-vous ?",
    html: `COLLER ICI LE HTML DU MAIL 1 (demande d'avis, sans cadeau)` , image: false },
  { colonne: "Roue envoyée le", delaiHeures: 72, sujet: "Merci {{prenom}} ! Ta roue cadeau t'attend 🎁",
    html: `COLLER ICI LE HTML DU MAIL 2 (roue, sans demande d'avis ; bouton et image vers {{lien_roue}})`, image: true, roue: true }
];

function imagesDuMail(avecImage) {
  return avecImage && ID_IMAGE_ROUE ? { roue: DriveApp.getFileById(ID_IMAGE_ROUE).getBlob() } : {};
}

function envoyerMails() {
  const feuille = SpreadsheetApp.getActive().getSheetByName("RDV");
  const donnees = feuille.getDataRange().getValues();
  const t = donnees[0].map(String);
  const c = nom => t.indexOf(nom);
  const [cP, cE, cD, cS, cStop, cCad, cCode, cFin] = ["Prénom", "Email", "Date RDV", "Statut", "Ne plus écrire", "Cadeau", "Code cadeau", "Valable jusqu'au"].map(c);
  const cols = MAILS.map(m => c(m.colonne));
  if ([cP, cE, cD, cS, cStop, cCad, cCode, cFin].concat(cols).some(i => i < 0)) throw new Error("En-têtes manquants dans l'onglet RDV.");

  const maintenant = new Date();
  let envois = 0;
  for (let i = 1; i < donnees.length && envois < MAX_PAR_PASSAGE; i++) {
    const l = donnees[i];
    const email = String(l[cE]).trim();
    const date = l[cD] instanceof Date ? l[cD] : null;
    if (!email || !date) continue;
    if (String(l[cS]).trim().toLowerCase() !== "fait") continue;
    if (String(l[cStop]).trim().toLowerCase() === "oui") continue;
    const heures = (maintenant - date) / 36e5;
    const prenom = String(l[cP]).trim() || "";
    MAILS.forEach((m, k) => {
      if (envois >= MAX_PAR_PASSAGE || l[cols[k]]) return;
      if (heures < m.delaiHeures || heures > m.delaiHeures + 72) return; // pas d'envoi en masse aux anciens RDV
      let html = m.html.replace(/{{prenom}}/g, prenom);
      if (m.roue) {
        const t = tirerCadeau();
        html = html.replace(/{{lien_roue}}/g, t.lien);
        feuille.getRange(i + 1, cCad + 1).setValue(t.cadeau);
        feuille.getRange(i + 1, cCode + 1).setValue(t.code);
        feuille.getRange(i + 1, cFin + 1).setValue(t.fin);
      }
      MailApp.sendEmail({
        to: email,
        subject: m.sujet.replace(/{{prenom}}/g, prenom),
        htmlBody: html,
        name: EXPEDITEUR,
        inlineImages: imagesDuMail(m.image)
      });
      feuille.getRange(i + 1, cols[k] + 1).setValue(new Date());
      envois++;
    });
  }
}

/** Tire le cadeau à l'avance : la roue s'arrêtera dessus, et tout est noté dans le tableau. */
function tirerCadeau() {
  const n = Math.floor(Math.random() * CADEAUX.length);
  const code = PREFIXE_CODE + "-" + Utilities.getUuid().replace(/-/g, "").slice(0, 5).toUpperCase();
  const fin = Utilities.formatDate(new Date(Date.now() + VALIDITE_JOURS * 864e5), "Europe/Paris", "dd/MM/yyyy");
  const lien = LIEN_ROUE + (LIEN_ROUE.indexOf("?") < 0 ? "?" : "&") + "l=" + n + "&k=" + encodeURIComponent(code) + "&f=" + encodeURIComponent(fin);
  return { cadeau: CADEAUX[n], code: code, fin: fin, lien: lien };
}

/** À lancer UNE fois : crée le passage automatique toutes les heures. */
function installer() {
  ScriptApp.getProjectTriggers().forEach(d => ScriptApp.deleteTrigger(d));
  ScriptApp.newTrigger("envoyerMails").timeBased().everyHours(1).create();
}

/** Pour tester : envoie les deux mails à ta propre adresse. */
function testerSurMoi() {
  MAILS.forEach(m => MailApp.sendEmail({
    to: Session.getActiveUser().getEmail(),
    subject: "[TEST] " + m.sujet.replace(/{{prenom}}/g, "Test"),
    htmlBody: m.html.replace(/{{prenom}}/g, "Test").replace(/{{lien_roue}}/g, m.roue ? tirerCadeau().lien : ""),
    name: EXPEDITEUR,
    inlineImages: imagesDuMail(m.image)
  }));
}
