"""Image de la roue pour le mail : roue-mail.gif (elle tourne puis s'arrête) + roue-mail.png (fixe).
Kit Avis Google, méthode Mel Nourdi.
Usage : python roue-image.py
Modifie seulement le bloc RÉGLAGES (couleurs : voir references/ambiances.md, colonnes « roue », « bouton », « foncé », « ticket »).
Gmail, Apple Mail et Outlook affichent le GIF animé (Outlook ordinateur peut montrer seulement la 1re image : c'est la roue à l'arrêt, ça reste joli).
"""
import math
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ===== RÉGLAGES =====
CADEAUX = [("−10 %", "prochaine séance"), ("15 min", "en plus"), ("1 bilan", "offert"),
           ("−20 €", "sur un pack"), ("1 fiche", "d'exercices"), ("1 appel", "de suivi")]   # (gros, petit), même ordre que la roue en ligne
COULEURS = ["#1F3A5F", "#F6C9A0", "#E9EFF6"]   # colonne « roue » de l'ambiance
FONCE = "#1F3A5F"       # anneau et centre
POINTE = "#F2A65A"      # colonne « bouton »
FOND_GIF = "#FDF1E6"    # colonne « ticket » (le GIF n'a pas de transparence propre)
LOGO = "H"              # 1 ou 2 initiales
# ====================

S, W, G = 3, 560, 360   # suréchantillonnage, taille PNG, taille GIF


def police(t, gras=True):
    noms = (["Inter-Bold.otf", "Arial Bold.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"] if gras
            else ["Inter-Medium.otf", "Arial.ttf", "arial.ttf", "DejaVuSans.ttf"])
    for n in noms:
        for d in ("", "/usr/share/fonts/opentype/inter/", "/usr/share/fonts/truetype/dejavu/"):
            try:
                return ImageFont.truetype(d + n, int(t * S))
            except OSError:
                pass
    return ImageFont.load_default()


def clair(h):
    r, g, b = (int(h[i:i + 2], 16) for i in (1, 3, 5))
    return 0.299 * r + 0.587 * g + 0.114 * b > 150


def rgba(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5)) + (255,)


T = W * S; c = T / 2; Rext = T / 2 - 34 * S; R = Rext - 18 * S
n = len(CADEAUX); pas = 360 / n


def disque():
    im = Image.new("RGBA", (T, T), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for i in range(n):
        a0 = -90 + i * pas - pas / 2
        d.pieslice([c - R, c - R, c + R, c + R], a0, a0 + pas, fill=COULEURS[i % len(COULEURS)], outline="#ffffff", width=3 * S)
    taille = 30 if n <= 6 else 24
    for i, (gros, petit) in enumerate(CADEAUX):
        a0 = -90 + i * pas - pas / 2; col = COULEURS[i % len(COULEURS)]
        ink = FONCE if clair(col) else "#ffffff"
        lay = Image.new("RGBA", (int(R * 0.9), int(80 * S)), (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        cx = lay.width * 0.52
        ld.text((cx, lay.height / 2 - 12 * S), gros, font=police(taille), fill=ink, anchor="mm")
        ld.text((cx, lay.height / 2 + 16 * S), petit, font=police(12.5, False), fill=ink, anchor="mm")
        mid = a0 + pas / 2
        flip = 180 if math.sin(math.radians(mid)) > 0.01 else 0   # texte jamais à l'envers à l'arrêt
        rot = lay.rotate(-(mid + 90) + flip, expand=True, resample=Image.BICUBIC)
        x = c + math.cos(math.radians(mid)) * R * 0.60; y = c + math.sin(math.radians(mid)) * R * 0.60
        im.alpha_composite(rot, (int(x - rot.width / 2), int(y - rot.height / 2)))
    return im


def cadre(fond):
    base = Image.new("RGBA", (T, T), fond)
    sh = Image.new("RGBA", (T, T), (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse([c - Rext, c - Rext + 12 * S, c + Rext, c + Rext + 12 * S], fill=(0, 0, 0, 60))
    base.alpha_composite(sh.filter(ImageFilter.GaussianBlur(14 * S)))
    d = ImageDraw.Draw(base); d.ellipse([c - Rext, c - Rext, c + Rext, c + Rext], fill=FONCE)
    for k in range(24):
        a = math.radians(k * 15); x, y = c + math.cos(a) * (Rext - 9 * S), c + math.sin(a) * (Rext - 9 * S); rr = 3.6 * S
        d.ellipse([x - rr, y - rr, x + rr, y + rr], fill=POINTE if k % 2 == 0 else "#ffffff")
    return base


def dessus(im):
    d = ImageDraw.Draw(im); rc = 40 * S
    d.ellipse([c - rc, c - rc, c + rc, c + rc], fill="#ffffff", outline=POINTE, width=4 * S)
    d.text((c, c), LOGO, font=police(30 if len(LOGO) == 1 else 24), fill=FONCE, anchor="mm")
    top = c - Rext
    d.polygon([(c - 20 * S, top - 22 * S), (c + 20 * S, top - 22 * S), (c, top + 26 * S)], fill=POINTE)
    d.ellipse([c - 7 * S, top - 17 * S, c + 7 * S, top - 3 * S], fill="#ffffff")
    return im


def main():
    disk = disque()

    def image(angle, fond):
        im = cadre(fond); im.alpha_composite(disk.rotate(-angle, resample=Image.BICUBIC)); return dessus(im)

    image(0, (0, 0, 0, 0)).resize((W, W), Image.LANCZOS).save("roue-mail.png", optimize=True)
    N = 30; images = []; durees = []
    for k in range(N + 1):
        e = 1 - (1 - k / N) ** 3
        images.append(image(-720 * e, rgba(FOND_GIF)).convert("RGB").resize((G, G), Image.LANCZOS)
                      .quantize(colors=64, method=Image.MEDIANCUT, dither=Image.Dither.NONE))
        durees.append(45)
    durees[-1] = 2200
    images[-1].save("roue-mail.gif", save_all=True, append_images=images[:-1], duration=[durees[-1]] + durees[:-1], loop=0, optimize=True)
    print("roue-mail.gif et roue-mail.png créées")


if __name__ == "__main__":
    main()
