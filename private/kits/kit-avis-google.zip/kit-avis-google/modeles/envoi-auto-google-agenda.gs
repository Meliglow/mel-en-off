/**
 * ENVOI AUTOMATIQUE DEPUIS GOOGLE AGENDA — Kit Avis Google (Mel Nourdi)
 * Gratuit, avec un compte Google (Gmail gratuit ou Workspace). Rien à remplir au quotidien.
 *
 * Toutes les heures, le script lit ton Google Agenda :
 *   FORMULE 2 (deux mails) : la demande d'avis 24 h (ou 48 h) après la fin du rendez-vous,
 *                            puis le merci avec la roue cadeau 3 jours après.
 *   FORMULE 1 (un seul mail) : 24 h (ou 48 h) après, un mail avec la demande d'avis puis la roue
 *                            offerte à tous (modèle mail-avis-et-roue.html).
 * Chaque mail part UNE seule fois par rendez-vous.
 *
 * Où il trouve le client : un invité du rendez-vous (ex. réservation via ta page Google Agenda),
 * sinon une adresse email écrite dans la description du rendez-vous.
 * Rien ne part si : pas d'email trouvé, rendez-vous sur la journée entière, titre qui contient
 * « lapin », « annulé » ou « perso », ou client qui a demandé à ne plus recevoir de mails.
 *
 * Le suivi se remplit tout seul dans un Google Sheets « Kit avis – suivi » créé par « installer » :
 * date, client, mail envoyé, cadeau, code cadeau, valable jusqu'au. Quand un client montre son
 * code, tu le retrouves là (Ctrl+F). Onglet « Ne plus écrire » : les adresses à ne plus contacter
 * (le script y ajoute tout seul les clients qui répondent « STOP »).
 *
 * L'assistant remplace FORMULE, EXPEDITEUR, les SUJETS, les HTML, LIEN_ROUE, CADEAUX, PREFIXE_CODE.
 * Image de la roue dans le mail : <img src="cid:roue"> (fichier roue-mail.gif ou .png déposé dans Google Drive).
 */

const FORMULE = 2;                           // 1 = un seul mail (avis + roue), 2 = deux mails
const EXPEDITEUR = "Hugo Lefèvre";          // nom affiché
const AGENDA_ID = "";                        // vide = ton agenda principal
const DELAI_AVIS_HEURES = 24;                // 24 ou 48 (toujours moins que DELAI_ROUE_HEURES)
const DELAI_ROUE_HEURES = 72;                // 3 jours
const MAX_PAR_PASSAGE = 40;                  // marge sous la limite d'envoi de Gmail
const ID_IMAGE_ROUE = "";                    // identifiant Google Drive de roue-mail.gif (dans le mail : <img src="cid:roue">)
const LIEN_ROUE = "";                        // adresse de ta roue en ligne
const CADEAUX = ["-10 % sur ta prochaine séance", "15 min en plus", "Un bilan offert", "-20 € sur un pack", "Une fiche d'exercices", "Un appel de suivi"]; // MÊME ordre que dans la roue
const PREFIXE_CODE = "HUG";
const VALIDITE_JOURS = 60;
const MOTS_A_IGNORER = ["lapin", "annul", "perso"];

const MAILS = FORMULE === 1 ? [
  { type: "avis", delaiHeures: DELAI_AVIS_HEURES, sujet: "{{prenom}}, comment tu as vécu ta séance ?",
    html: `COLLER ICI LE HTML DE mail-avis-et-roue.html`, image: true, roue: true }
] : [
  { type: "avis", delaiHeures: DELAI_AVIS_HEURES, sujet: "{{prenom}}, comment tu as vécu ta séance ?",
    html: `COLLER ICI LE HTML DE mail-demande-avis.html (sans cadeau)`, image: false },
  { type: "roue", delaiHeures: DELAI_ROUE_HEURES, sujet: "{{prenom}}, un petit cadeau t'attend 🎁",
    html: `COLLER ICI LE HTML DE mail-roue.html (sans demande d'avis)`, image: true, roue: true }
];

/* ---------- le passage automatique ---------- */

function envoyerMails() {
  const suivi = feuilleSuivi_();
  const dejaFait = new Set(suivi.getRange(1, 1, Math.max(1, suivi.getLastRow()), 1).getValues().map(l => String(l[0])));
  const stop = listeStop_();
  const moi = (Session.getEffectiveUser().getEmail() || "").toLowerCase();
  const agenda = AGENDA_ID ? CalendarApp.getCalendarById(AGENDA_ID) : CalendarApp.getDefaultCalendar();
  const maintenant = new Date();
  const plusLong = Math.max.apply(null, MAILS.map(m => m.delaiHeures)) + 72;
  const evenements = agenda.getEvents(new Date(maintenant - plusLong * 36e5), maintenant);
  let envois = 0;

  for (const ev of evenements) {
    if (envois >= MAX_PAR_PASSAGE) break;
    if (ev.isAllDayEvent()) continue;
    const titre = (ev.getTitle() || "").toLowerCase();
    if (MOTS_A_IGNORER.some(m => titre.indexOf(m) >= 0)) continue;
    const client = clientDe_(ev, moi);
    if (!client || stop.has(client.email)) continue;
    const heures = (maintenant - ev.getEndTime()) / 36e5;
    const cleRdv = ev.getId() + "|" + ev.getStartTime().toISOString();

    for (const m of MAILS) {
      if (envois >= MAX_PAR_PASSAGE) break;
      const cle = cleRdv + "|" + m.type;
      if (dejaFait.has(cle)) continue;
      // Fenêtre de chaque mail : la demande d'avis jusqu'au moment de la roue, la roue pendant 3 jours.
      // Jamais d'envoi en masse aux anciens rendez-vous, et jamais les deux mails en même temps.
      const finFenetre = m.type === "avis" ? (FORMULE === 1 ? m.delaiHeures + 72 : DELAI_ROUE_HEURES) : m.delaiHeures + 72;
      if (heures < m.delaiHeures || heures >= finFenetre) continue;
      let html = m.html.replace(/{{prenom}}/g, client.prenom);
      let t = { cadeau: "", code: "", fin: "" };
      if (m.roue) { t = tirerCadeau(); html = html.replace(/{{lien_roue}}/g, t.lien); }
      MailApp.sendEmail({
        to: client.email,
        subject: sujet_(m.sujet, client.prenom),
        htmlBody: html,
        name: EXPEDITEUR,
        inlineImages: imagesDuMail_(m.image)
      });
      suivi.appendRow([cle, new Date(), client.prenom, client.email, m.type === "avis" ? (m.roue ? "Avis + roue" : "Demande d'avis") : "Roue cadeau", t.cadeau, t.code, t.fin]);
      dejaFait.add(cle);
      envois++;
      break; // un seul mail par rendez-vous et par passage
    }
  }
}

/** Le sujet avec le prénom ; sans prénom connu : « Comment s'est passé ton rendez-vous ? », « Merci ! … ». */
function sujet_(modele, prenom) {
  const s = prenom ? modele.replace(/{{prenom}}/g, prenom) : modele.replace(/{{prenom}}\s*,\s*/g, "").replace(/\s*{{prenom}}/g, "");
  return s.trim().replace(/^./, c => c.toUpperCase());
}

/** Trouve le client : un invité (pas toi), sinon un email dans la description. */
function clientDe_(ev, moi) {
  const invites = ev.getGuestList(false).filter(g => g.getEmail() && g.getEmail().toLowerCase() !== moi);
  let email = "", nom = "";
  if (invites.length) { email = invites[0].getEmail(); nom = invites[0].getName() || ""; }
  const desc = (ev.getDescription() || "").replace(/<[^>]+>/g, " ");
  if (!email) { const m = desc.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i); if (m) email = m[0]; }
  if (!email || email.toLowerCase() === moi) return null;
  if (!nom || nom.indexOf("@") >= 0) { const m = desc.match(/(?:pr[ée]nom|first name|nom)\s*:?\s*([A-Za-zÀ-ÿ'-]+)/i); if (m) nom = m[1]; }
  const prenom = (nom.split(/\s+/)[0] || "").replace(/^./, c => c.toUpperCase());
  return { email: email.toLowerCase(), prenom: prenom };
}

/* ---------- la roue ---------- */

/** Tire le cadeau à l'avance : la roue s'arrêtera dessus, et tout est noté dans le suivi. */
function tirerCadeau() {
  const n = Math.floor(Math.random() * CADEAUX.length);
  const code = PREFIXE_CODE + "-" + Utilities.getUuid().replace(/-/g, "").slice(0, 5).toUpperCase();
  const fin = Utilities.formatDate(new Date(Date.now() + VALIDITE_JOURS * 864e5), "Europe/Paris", "dd/MM/yyyy");
  const lien = LIEN_ROUE + (LIEN_ROUE.indexOf("?") < 0 ? "?" : "&") + "l=" + n + "&k=" + encodeURIComponent(code) + "&f=" + encodeURIComponent(fin);
  return { cadeau: CADEAUX[n], code: code, fin: fin, lien: lien };
}

function imagesDuMail_(avecImage) {
  return avecImage && ID_IMAGE_ROUE ? { roue: DriveApp.getFileById(ID_IMAGE_ROUE).getBlob() } : {};
}

/* ---------- le suivi (créé tout seul) ---------- */

function classeur_() {
  const p = PropertiesService.getScriptProperties();
  let id = p.getProperty("ID_SUIVI");
  if (id) { try { return SpreadsheetApp.openById(id); } catch (e) { /* supprimé : on le recrée */ } }
  const ss = SpreadsheetApp.create("Kit avis – suivi");
  const f = ss.getSheets()[0];
  f.setName("Suivi");
  f.appendRow(["Clé (ne pas toucher)", "Envoyé le", "Prénom", "Email", "Mail", "Cadeau", "Code cadeau", "Valable jusqu'au"]);
  f.setFrozenRows(1); f.hideColumns(1);
  ss.insertSheet("Ne plus écrire").appendRow(["Email"]);
  p.setProperty("ID_SUIVI", ss.getId());
  return ss;
}
function feuilleSuivi_() { return classeur_().getSheetByName("Suivi"); }

/** Les adresses à ne plus contacter : l'onglet + les réponses « STOP » reçues dans Gmail. */
function listeStop_() {
  const f = classeur_().getSheetByName("Ne plus écrire");
  const set = new Set(f.getRange(1, 1, Math.max(1, f.getLastRow()), 1).getValues().map(l => String(l[0]).trim().toLowerCase()).filter(Boolean));
  GmailApp.search('in:inbox newer_than:60d (subject:STOP OR "STOP")', 0, 50).forEach(fil => fil.getMessages().forEach(msg => {
    const corps = (msg.getPlainBody() || "").trim().split(/\n/)[0].trim().toUpperCase();
    if (/^STOP\b/.test(corps) || /^(re: ?)?stop\b/i.test(msg.getSubject() || "")) {
      const m = (msg.getFrom() || "").match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
      if (m && !set.has(m[0].toLowerCase())) { set.add(m[0].toLowerCase()); f.appendRow([m[0].toLowerCase()]); }
    }
  }));
  return set;
}

/* ---------- installation et test ---------- */

/** À lancer UNE fois : crée le suivi et le passage automatique toutes les heures. */
function installer() {
  classeur_();
  ScriptApp.getProjectTriggers().forEach(d => ScriptApp.deleteTrigger(d));
  ScriptApp.newTrigger("envoyerMails").timeBased().everyHours(1).create();
}

/** Pour tester : envoie les deux mails à ta propre adresse. */
function testerSurMoi() {
  MAILS.forEach(m => MailApp.sendEmail({
    to: Session.getActiveUser().getEmail(),
    subject: "[TEST] " + m.sujet.replace(/{{prenom}}/g, "Test"),
    htmlBody: m.html.replace(/{{prenom}}/g, "Test").replace(/{{lien_roue}}/g, m.roue ? tirerCadeau().lien : ""),
    name: EXPEDITEUR,
    inlineImages: imagesDuMail_(m.image)
  }));
}

/** Pour vérifier sans rien envoyer : liste ce que le script trouve dans ton agenda des 7 derniers jours. */
function verifierMonAgenda() {
  const moi = (Session.getEffectiveUser().getEmail() || "").toLowerCase();
  const agenda = AGENDA_ID ? CalendarApp.getCalendarById(AGENDA_ID) : CalendarApp.getDefaultCalendar();
  agenda.getEvents(new Date(Date.now() - 7 * 864e5), new Date()).forEach(ev => {
    const c = clientDe_(ev, moi);
    Logger.log(ev.getTitle() + " → " + (c ? c.prenom + " <" + c.email + ">" : "aucun email trouvé, rien ne partira"));
  });
}
