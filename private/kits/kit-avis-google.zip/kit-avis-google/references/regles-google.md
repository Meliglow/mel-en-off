# Règles Google sur les avis (résumé fidèle)

Source : règlement Google Maps « Contenus interdits et soumis à des restrictions », https://support.google.com/contributionpolicy/answer/7400114?hl=fr, lu le 25/11/2026.

## Interdit
- Proposer des avantages (paiement, remises, produits ou services gratuits) en échange de la publication d'un avis. Pareil pour faire modifier ou retirer un avis négatif.
- Les avis ou notes payés, directement ou en nature.
- Solliciter des avis positifs de façon sélective (ne demander qu'aux clients contents).
- Déconseiller ou interdire de publier des avis négatifs.
- Obliger quelqu'un à laisser une note ou un avis sur place.

## Autorisé
- Demander ou encourager des avis qui racontent une vraie expérience, sans avantage en échange.

## Ce que ça veut dire pour la roue
- La roue est offerte à TOUS les clients après leur rendez-vous, qu'ils laissent un avis ou non.
- Aucun texte ne relie les deux : pas de « un avis = un cadeau », pas de « laisse un avis pour tourner la roue », pas de vérification de l'avis avant le cadeau.
- Formule 2 mails (la plus prudente) : avis à 24 h, roue à 3 jours. Le mail d'avis ne parle pas de la roue, le mail roue ne parle pas d'avis.
- Formule 1 mail : la demande d'avis d'abord, puis « Et pour te remercier de ta confiance, un tour de roue t'attend. Offert à tous mes clients. » La roue ne dépend jamais de l'avis, et aucun texte ne dit le contraire.

## Exemples
- ❌ « Laisse-nous un avis 5 étoiles et gagne un soin ! »
- ❌ « Un avis = un cadeau 🎁 »
- ❌ Mail envoyé seulement aux clients qui ont mis 4 ou 5 à un petit sondage.
- ❌ « Pour te remercier d'avoir pris ce temps (ton avis), tourne la roue. »
- ❌ « Montre-nous ton avis au cabinet pour recevoir ton cadeau. »
- ✅ Mail 1 (24 h) : « Merci d'être venu ! Si tu as une minute, ton avis sincère sur Google aide d'autres personnes à me trouver. »
- ✅ Mail 2 (3 jours) : « Merci encore d'être venu ! Ta roue cadeau t'attend pour ta prochaine visite. »
- ✅ Formule 1 mail : « Partage ton expérience sur ma fiche Google, quelle que soit la note. » puis « Et pour te remercier de ta confiance, un tour de roue t'attend. Offert à tous mes clients. »

## Vérifié le 26/11/2026 (aide Google Business Profile)
- Lien et QR code d'avis officiels : business.google.com > « Voir les avis » > « Recevoir plus d'avis » (icône de partage) > « Copier » ; QR code : clic droit > « Enregistrer l'image sous ». Le QR code ne se crée que depuis un ordinateur.
- Offrir des produits ou services gratuits ou à prix réduit EN ÉCHANGE d'avis est interdit (« engagement artificiel »), comme demander de modifier ou supprimer un avis négatif.
- Réponses : Google les examine avant publication (en général 10 minutes, parfois jusqu'à 30 jours).
- Signaler : « Voir les avis » > « Signaler » > raison > envoyer. Seuls les avis qui enfreignent les règles sont retirés. Suivi et appel (un seul) dans l'outil de gestion des avis.
- Extorsion (avis négatifs puis demande d'argent) : ne pas répondre, ne pas payer, garder les preuves, formulaire Google dédié.
