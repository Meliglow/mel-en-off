# Les 6 ambiances du kit (usage interne)

Ne montre JAMAIS de code couleur (#…) à la personne. Elle choisit en VOYANT son mail dans 3 ambiances (`modeles/apercu-ambiances.html`), avec des pastilles de couleur. Ici, les codes sont pour toi seul.

Dans les modèles de mail, remplace les 6 codes de l'exemple (Bleu nuit) par ceux de l'ambiance choisie :
`#1F3A5F` → foncé · `#F2A65A` → bouton · `#F6C9A0` → étoiles · `#FDF1E6` → ticket · `#E8BE96` → bord du ticket · `#EEF1F5` → fond.

| Ambiance | Pour qui (exemples) | foncé | bouton | étoiles | ticket | bord ticket | fond | roue (3 couleurs) |
|---|---|---|---|---|---|---|---|---|
| Bleu nuit | coach, santé, ostéo, kiné, conseil, artisans | #1F3A5F | #F2A65A | #F6C9A0 | #FDF1E6 | #E8BE96 | #EEF1F5 | #1F3A5F, #F6C9A0, #E9EFF6 |
| Sauge | naturel, soins, bien-être, naturopathe, fleuriste | #2F5246 | #E9C46A | #F1DCA0 | #F7F1E3 | #D9C79B | #EEF2EE | #2F5246, #F1DCA0, #E4EEE7 |
| Nude rosé | esthétique, beauté, coiffure, mariage, photo | #6E3B34 | #E8A598 | #F4C7BC | #FBEFEA | #E6BFB3 | #F6EFEC | #6E3B34, #F4C7BC, #FBEFEA |
| Noir et or | haut de gamme, barbier, joaillerie, coaching premium | #1E1E1E | #C9A45C | #E3C98F | #F7F1E6 | #D9C29A | #EFEDE8 | #1E1E1E, #C9A45C, #F3ECDF |
| Corail | sport, enfants, restauration, énergie | #2B2D42 | #EF6F4F | #F7A48C | #FFF0E9 | #F4B9A5 | #F2F1F4 | #2B2D42, #F7A48C, #FFF0E9 |
| Lavande | zen, yoga, sophrologie, massage, psy | #3E3463 | #B9A6E8 | #D6CBF3 | #F4F0FB | #CFC2EC | #F1EFF6 | #3E3463, #D6CBF3, #F4F0FB |

Choisis les 3 qui vont le mieux avec le métier (la plus évidente en premier).

**« Mes couleurs »** : si la personne envoie son logo, une capture de son site ou de son Instagram, tire de l'image 1 couleur foncée (foncé), 1 couleur vive (bouton), et fabrique les autres en plus clair (étoiles, ticket, bord, fond). Crée une 4e ambiance « Tes couleurs » et montre-la sur le même aperçu. Le texte sur le bouton reste foncé : si le bouton est trop sombre pour ça, éclaircis-le. Si elle te donne le lien de son site et que tu peux l'ouvrir, fais pareil. Sinon, garde l'ambiance choisie.
