/**
 * MES DEVIS : tableau de suivi, relances et paiement de l'acompte — Kit Devis pro (Mel Nourdi)
 * Il faut : un compte Gmail (gratuit). En option : un compte de paiement gratuit (pour l'acompte en ligne).
 *
 * CE QUE ÇA FAIT, TOUTES LES HEURES :
 *  1. Repère dans ton Gmail les devis envoyés : objet « Devis D-2026-014 · Julie Moreau · 1 660 € ».
 *     Une ligne par devis dans l'onglet « Devis ».
 *  2. Devis signé (mail de signature reçu, ou « Signé » choisi par toi) : si le paiement est branché,
 *     ton client reçoit tout de suite un mail avec 2 boutons : payer l'acompte, ou payer le total.
 *     Le paiement en 3 fois s'affiche tout seul si tu l'as activé dans ton compte de paiement.
 *  3. Paiement reçu : la ligne passe en « Acompte payé » ou « Payé en entier ».
 *  4. Relances (aucune, 1 ou 2, ton choix) : du lundi au vendredi, le matin, en réponse à ton devis.
 *     Jamais après la date de validité. Arrêt dès que le client répond ou signe.
 *  5. En haut : montant en attente, montant signé, taux de signature.
 *  7. TON TABLEAU DE BORD : une jolie page (chiffres du mois, à savoir aujourd'hui, devis, clients)
 *     à ouvrir comme une appli. Déployer > Nouveau déploiement > Application Web.
 *  6. Onglet « Clients » : ta base clients. Chaque nouveau client d'un devis y est ajouté tout seul
 *     (nom, email). Tu as déjà une liste dans un autre outil ? Exporte-la en CSV, puis dans l'onglet
 *     « Clients » : Fichier > Importer > Importer > ton fichier > « Ajouter à la feuille actuelle ».
 *     Pour la sortir : Fichier > Télécharger > CSV.
 *
 * INSTALLATION (une fois, 5 minutes) :
 *  1. Ouvre sheets.new, nomme le tableau « Mes devis ».
 *  2. Menu Extensions > Apps Script. Efface tout, colle ce fichier, clique sur Enregistrer.
 *  3. Choisis la fonction « installer » en haut, clique sur Exécuter, puis Autoriser.
 *  4. (Option paiement) Reviens au tableau : menu « Mes devis » > « Brancher le paiement », colle ta clé.
 * L'assistante remplit le bloc RÉGLAGES avec tes réponses.
 */

// ===== RÉGLAGES (remplis par l'assistante) =====
const RELANCES = 2;                 // 0 = aucune, 1 = une relance (4 jours après), 2 = deux relances (3 et 8 jours après)
const VALIDITE_JOURS = 30;          // durée de validité de tes devis
const ACOMPTE_POURCENT = 30;        // 0 = pas de paiement en ligne
const NOM_PRO = "Sarah Martin Design";
const COULEUR = "#1F4D3F";            // couleurs du tableau de bord (celles de tes devis)
const ACCENT = "#E9B44C";
const LIEN_SIGNATURE = "";          // adresse de ton compte de signature (bouton dans le tableau de bord), vide = pas de bouton
const OBJECTIF_MOIS = 0;            // ton objectif d'encaissement du mois en euros (0 = pas d'objectif affiché)
const ADRESSE_PRO = "12 rue des Lilas\n69003 Lyon";   // pour l'en-tête du devis
const SIRET = "123 456 789 00012";
const TAUX_TVA = 0;                  // 0 si tu es en franchise de TVA, sinon 20, 10…
const MENTION_TVA = "TVA non applicable, art. 293 B du CGI";
const TEXTE_ENVOI = "Bonjour {prenom},\n\nVoici le devis {numero} pour ton projet, d'un montant de {total}. Il est valable jusqu'au {validite}.\n\nTu vas recevoir un lien pour le signer en ligne. Si tu as une question, réponds simplement à ce mail.\n\nBelle journée,\n{signature}";
const SIGNATURE = "Sarah\nSarah Martin Design";
const TEXTE_RELANCE_1 = "Bonjour {prenom},\n\nTu as pu regarder le devis {numero} ? Si une ligne n'est pas claire ou si tu veux ajuster quelque chose, réponds simplement à ce mail.\n\nBelle journée,\n{signature}";
const TEXTE_RELANCE_2 = "Bonjour {prenom},\n\nJe reviens vers toi une dernière fois pour le devis {numero}. Il reste valable jusqu'au {validite}. S'il ne correspond plus à ton projet, dis-le-moi sans souci : je ne te relancerai plus.\n\nBelle journée,\n{signature}";
const TEXTE_PAIEMENT = "Bonjour {prenom},\n\nMerci pour ta signature ! Pour lancer le projet, il te reste à régler l'acompte de {acompte}.\n\n{bouton_acompte}\n\nTu peux aussi régler le total de {total} en une fois :\n{bouton_total}\n\nLe paiement en plusieurs fois t'est proposé sur la page de paiement si tu y as droit.\n\nÀ très vite,\n{signature}";
// ===============================================

const ID_TABLEUR = "";              // laisse vide (sert seulement si le programme n'est pas rangé dans le tableau)
function ss_() { return SpreadsheetApp.getActive() || SpreadsheetApp.openById(ID_TABLEUR); }
const ONGLET = "Devis";
const ONGLET_CLIENTS = "Clients";
const ENTETES_CLIENTS = ["Nom", "Email", "Téléphone", "Adresse", "SIRET (si pro)", "Notes"];
const ENTETES = ["N° devis", "Client", "Email", "Montant", "Envoyé le", "Valable jusqu'au", "Relance 1", "Relance 2", "Statut", "Paiement", "Lien acompte", "Lien total", "Fil Gmail", "Encaissé", "Payé le", "Détail"];
const C = Object.fromEntries(ENTETES.map((h, i) => [h, i]));
const STATUTS = ["En attente", "Répondu", "Signé", "Refusé", "Expiré", "Pause"];
const FINIS = ["Refusé", "Expiré", "Pause"];

function onOpen() {
  SpreadsheetApp.getUi().createMenu("Mes devis")
    .addItem("Mettre à jour maintenant", "chaqueHeure")
    .addItem("Brancher le paiement", "brancherPaiement")
    .addItem("M'envoyer le lien de mon appli", "envoyerMonLien")
    .addToUi();
}

function installer() {
  preparer_();
  ScriptApp.getProjectTriggers().forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger("chaqueHeure").timeBased().everyHours(1).create();
  chaqueHeure();
}

function preparer_() {
  const ss = ss_();
  let f = ss.getSheetByName(ONGLET);
  if (!f) { f = ss.getSheets()[0]; f.setName(ONGLET); }
  f.clear();
  f.getRange("A1").setValue("Mes devis").setFontSize(18).setFontWeight("bold");
  f.getRange("A2").setValue("En attente"); f.getRange("B2").setFormula('=SUMIF(I5:I,"En attente",D5:D)+SUMIF(I5:I,"Répondu",D5:D)');
  f.getRange("C2").setValue("Signé"); f.getRange("D2").setFormula('=SUMIF(I5:I,"Signé",D5:D)');
  f.getRange("E2").setValue("Taux de signature"); f.getRange("F2").setFormula('=IFERROR(COUNTIF(I5:I,"Signé")/COUNTA(A5:A),0)');
  f.getRange("B2:D2").setNumberFormat('#,##0.00 "€"'); f.getRange("F2").setNumberFormat("0 %");
  f.getRange("A2:F2").setFontWeight("bold");
  f.getRange(4, 1, 1, ENTETES.length).setValues([ENTETES]).setFontWeight("bold").setBackground("#161616").setFontColor("#ffffff");
  f.setFrozenRows(4);
  f.getRange("D5:D").setNumberFormat('#,##0.00 "€"');
  f.getRange("E5:H").setNumberFormat("dd/mm/yyyy");
  f.getRange("I5:I").setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(STATUTS, true).build());
  f.hideColumns(C["Lien acompte"] + 1, 3);
  f.hideColumns(C["Détail"] + 1);
  f.getRange(5, C["Encaissé"] + 1, f.getMaxRows() - 4, 1).setNumberFormat('#,##0.00 "€"');
  f.getRange(5, C["Payé le"] + 1, f.getMaxRows() - 4, 1).setNumberFormat("dd/mm/yyyy");
  f.setColumnWidth(2, 160); f.setColumnWidth(3, 200);
  clients_(ss);
  tarifs_(ss);
}

// Onglet « Clients » : créé s'il manque, jamais effacé (ta liste importée reste).
function clients_(ss) {
  let c = ss.getSheetByName(ONGLET_CLIENTS);
  if (!c) {
    c = ss.insertSheet(ONGLET_CLIENTS);
    c.getRange(1, 1, 1, ENTETES_CLIENTS.length).setValues([ENTETES_CLIENTS]).setFontWeight("bold").setBackground("#161616").setFontColor("#ffffff");
    c.setFrozenRows(1); c.setColumnWidth(1, 180); c.setColumnWidth(2, 220); c.setColumnWidth(4, 260);
  }
  return c;
}

function ajouterClient_(nom, email, tel, adresse, origine) {
  email = String(email || "").replace(/^.*<|>.*$/g, "").trim().toLowerCase();
  if (!email && !tel) return false;
  const c = clients_(ss_());
  const n = c.getLastRow();
  if (n > 1) {
    const vus = c.getRange(2, 1, n - 1, c.getLastColumn()).getValues().some(r => (email && String(r[1]).trim().toLowerCase() === email) || (!email && String(r[2]).replace(/\D/g, "") === String(tel).replace(/\D/g, "")));
    if (vus) return false;
  }
  c.appendRow([nom, email, tel || "", adresse || "", "", (origine || "Ajouté avec un devis") + " le " + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "dd/MM/yyyy")]);
  return true;
}

function brancherPaiement() {
  const ui = SpreadsheetApp.getUi();
  const r = ui.prompt("Brancher le paiement", "Colle ici ta clé (elle commence par rk_ ou sk_). Elle reste dans ton compte Google, personne d'autre ne la voit.", ui.ButtonSet.OK_CANCEL);
  if (r.getSelectedButton() !== ui.Button.OK) return;
  const cle = r.getResponseText().trim();
  if (!/^(rk|sk)_(test|live)_/.test(cle)) { ui.alert("Cette clé ne ressemble pas à une clé de paiement. Rien n'a été changé."); return; }
  PropertiesService.getScriptProperties().setProperty("CLE_PAIEMENT", cle);
  ui.alert(cle.indexOf("_test_") > 0 ? "Paiement branché en MODE TEST ✓ (aucun vrai paiement)." : "Paiement branché ✓");
}

function chaqueHeure() {
  const f = ss_().getSheetByName(ONGLET);
  ajouterNouveauxDevis_(f);
  const n = f.getLastRow() - 4;
  if (n < 1) return;
  const d = f.getRange(5, 1, n, ENTETES.length).getValues();
  const maintenant = new Date();
  const matinSemaine = maintenant.getDay() >= 1 && maintenant.getDay() <= 5 && maintenant.getHours() >= 9 && maintenant.getHours() < 12;
  const moi = Session.getEffectiveUser().getEmail().toLowerCase();
  const auj = new Date(); auj.setHours(0, 0, 0, 0);
  const cle = PropertiesService.getScriptProperties().getProperty("CLE_PAIEMENT");
  const set = (i, col, v) => f.getRange(i + 5, C[col] + 1).setValue(v);

  d.forEach((l, i) => {
    const num = l[C["N° devis"]], filId = l[C["Fil Gmail"]];
    if (!num || !filId) return;
    let statut = String(l[C["Statut"]] || "En attente");
    if (FINIS.includes(statut)) return;
    const prenom = String(l[C["Client"]]).split(" ")[0];
    const fin = l[C["Valable jusqu'au"]] instanceof Date ? l[C["Valable jusqu'au"]] : null;
    const vars = { prenom, numero: num, signature: SIGNATURE,
      validite: fin ? Utilities.formatDate(fin, Session.getScriptTimeZone(), "dd/MM/yyyy") : "" };

    // 1. Signé ? (mail de signature qui cite le numéro, ou statut choisi à la main)
    if (statut !== "Signé" && GmailApp.search('"' + num + '" (signé OR signed OR completed OR complété) newer_than:90d -in:sent', 0, 1).length) {
      statut = "Signé"; set(i, "Statut", statut);
    }
    if (statut === "Signé") {
      // 2. Paiement : envoi des liens une seule fois, puis suivi
      if (cle && ACOMPTE_POURCENT > 0) {
        if (!l[C["Lien acompte"]]) envoyerLiensPaiement_(f, i, l, vars, cle);
        else if (!/payé/i.test(l[C["Paiement"]])) suivrePaiement_(f, i, l, cle);
      }
      return;
    }
    // 3. Le client a répondu ? On ne relance plus.
    const fil = GmailApp.getThreadById(String(filId));
    if (!fil) return;
    if (fil.getMessages().some(m => m.getFrom().toLowerCase().indexOf(moi) < 0)) {
      if (statut !== "Répondu") set(i, "Statut", "Répondu"); return;
    }
    if (fin && auj > fin) { set(i, "Statut", "Expiré"); return; }
    // 4. Relances, en semaine, le matin
    if (!matinSemaine || RELANCES === 0) return;
    const envoye = l[C["Envoyé le"]] instanceof Date ? new Date(l[C["Envoyé le"]]) : null;
    if (!envoye) return;
    envoye.setHours(0, 0, 0, 0);
    const jours = Math.floor((auj - envoye) / 864e5);
    const j1 = RELANCES === 1 ? 4 : 3;
    if (!l[C["Relance 1"]] && jours >= j1) {
      repondre_(fil, remplir_(TEXTE_RELANCE_1, vars)); set(i, "Relance 1", new Date());
    } else if (RELANCES === 2 && l[C["Relance 1"]] && !l[C["Relance 2"]] && jours >= 8) {
      repondre_(fil, remplir_(TEXTE_RELANCE_2, vars)); set(i, "Relance 2", new Date());
    }
  });
}

function ajouterNouveauxDevis_(f) {
  const n = Math.max(f.getLastRow() - 4, 1);
  const connus = new Set(f.getRange(5, C["Fil Gmail"] + 1, n, 1).getValues().map(r => String(r[0])));
  GmailApp.search('in:sent subject:"Devis D-" newer_than:45d', 0, 50).reverse().forEach(fil => {
    if (connus.has(fil.getId())) return;
    const m = fil.getMessages()[0];
    const objet = m.getSubject();
    const num = (objet.match(/D-\d{4}-\d{2,4}/) || [""])[0];
    if (!num || !/^devis d-/i.test(objet.trim())) return;
    const parts = objet.split(/\s[·|–-]\s/);
    const montant = Number((parts[2] || "").replace(/[^\d,]/g, "").replace(",", ".")) || 0;
    const envoye = m.getDate();
    const fin = new Date(envoye); fin.setDate(fin.getDate() + VALIDITE_JOURS);
    const ligne = ENTETES.map(() => "");
    ligne[C["N° devis"]] = num; ligne[C["Client"]] = (parts[1] || "").trim(); ligne[C["Email"]] = m.getTo();
    ligne[C["Montant"]] = montant; ligne[C["Envoyé le"]] = envoye; ligne[C["Valable jusqu'au"]] = fin;
    ligne[C["Statut"]] = "En attente"; ligne[C["Fil Gmail"]] = fil.getId();
    f.appendRow(ligne);
    ajouterClient_(ligne[C["Client"]], m.getTo());
  });
}

// ---------- Paiement ----------
function api_(cle, methode, chemin, params) {
  const opts = { method: methode, headers: { Authorization: "Bearer " + cle }, muteHttpExceptions: true };
  if (params) opts.payload = params;
  const r = UrlFetchApp.fetch("https://api.stripe.com/v1/" + chemin, opts);
  const j = JSON.parse(r.getContentText());
  if (r.getResponseCode() >= 300) throw new Error("Paiement : " + (j.error && j.error.message));
  return j;
}

function creerLien_(cle, nom, centimes, num, type) {
  const prix = api_(cle, "post", "prices", { currency: "eur", unit_amount: String(centimes), "product_data[name]": nom });
  return api_(cle, "post", "payment_links", {
    "line_items[0][price]": prix.id, "line_items[0][quantity]": "1",
    "metadata[devis]": num, "metadata[type]": type,
    "after_completion[type]": "hosted_confirmation",
    "after_completion[hosted_confirmation][custom_message]": "Merci ! Ton paiement est bien reçu. " + NOM_PRO
  });
}

function envoyerLiensPaiement_(f, i, l, vars, cle) {
  const num = l[C["N° devis"]], total = Number(l[C["Montant"]]) || 0;
  if (!total) return;
  const acompte = Math.round(total * ACOMPTE_POURCENT) / 100;
  const la = creerLien_(cle, "Acompte devis " + num + " · " + NOM_PRO, Math.round(acompte * 100), num, "acompte");
  const lt = creerLien_(cle, "Devis " + num + " · " + NOM_PRO, Math.round(total * 100), num, "total");
  const eur = x => x.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";
  const texte = remplir_(TEXTE_PAIEMENT, Object.assign({}, vars, { acompte: eur(acompte), total: eur(total), bouton_acompte: la.url, bouton_total: lt.url }));
  const html = echapper_(texte)
    .replace(echapper_(la.url), bouton_("Régler l'acompte · " + eur(acompte), la.url, true))
    .replace(echapper_(lt.url), bouton_("Régler le total · " + eur(total), lt.url, false));
  GmailApp.sendEmail(String(l[C["Email"]]), "Ton acompte pour le devis " + num, texte, { htmlBody: html, name: NOM_PRO });
  f.getRange(i + 5, C["Lien acompte"] + 1, 1, 2).setValues([[la.id, lt.id]]);
  f.getRange(i + 5, C["Paiement"] + 1).setValue("Lien envoyé");
}

function suivrePaiement_(f, i, l, cle) {
  const paye = id => api_(cle, "get", "checkout/sessions?payment_link=" + id + "&status=complete&limit=5")
    .data.some(s => s.payment_status === "paid" || s.payment_status === "no_payment_required");
  const ligne = i + 5, montant = Number(l[C["Montant"]]) || 0;
  const noter = (etat, somme) => {
    f.getRange(ligne, C["Paiement"] + 1).setValue(etat);
    f.getRange(ligne, C["Encaissé"] + 1).setValue(somme);
    f.getRange(ligne, C["Payé le"] + 1).setValue(new Date());
  };
  if (paye(l[C["Lien total"]])) noter("Payé en entier", montant);
  else if (l[C["Paiement"]] !== "Acompte payé" && paye(l[C["Lien acompte"]])) noter("Acompte payé", Math.round(montant * ACOMPTE_POURCENT) / 100);
}

// ---------- Tableau de bord (application Web) ----------
// Envoie à l'acheteur (depuis son propre Gmail, à lui-même) le lien de son tableau de bord.
function envoyerMonLien() {
  const url = ScriptApp.getService().getUrl() || "";
  if (!/\/exec$/.test(url)) throw new Error("Déploie d'abord l'appli : Déployer > Nouveau déploiement > Application Web.");
  PropertiesService.getScriptProperties().setProperty("LIEN_APPLI", url);
  const moi = Session.getEffectiveUser().getEmail();
  const html = '<div style="font-family:Arial,sans-serif;font-size:15px;color:#222;max-width:520px">'
    + '<p><b>C\'est ici que tu consultes ton tableau de bord « Mes devis » :</b></p>'
    + '<p><a href="' + url + '" style="display:inline-block;background:' + COULEUR + ';color:#fff;padding:12px 20px;border-radius:999px;text-decoration:none;font-weight:bold">Ouvrir mon tableau de bord</a></p>'
    + '<p><b>Mets-le sur ton écran d\'accueil</b> (une seule fois) : ouvre ce mail sur ton téléphone et touche le bouton, puis :</p>'
    + '<p><b>iPhone (Safari)</b> : touche « ••• », puis « Partager », puis « Sur l\'écran d\'accueil ». Active « Ouvrir comme app web », puis touche « Ajouter ».</p>'
    + '<p><b>Android (Chrome)</b> : touche « ⋮ » en haut à droite, puis « Ajouter à l\'écran d\'accueil », puis confirme (« Créer un raccourci » ou « Installer »).</p>'
    + '<p>Tu auras une icône comme une appli.</p>'
    + '<p>Connecte-toi avec ce compte Google (' + moi + '). Si ton téléphone a plusieurs comptes Google, choisis celui-ci, sinon Google affiche une erreur.</p>'
    + '<p style="color:#777;font-size:13px">Lien complet : ' + url + '</p></div>';
  GmailApp.sendEmail(moi, "Ton tableau de bord Mes devis : le lien à garder", "C'est ici que tu consultes ton tableau de bord : " + url, { htmlBody: html, name: "Mes devis" });
  return url;
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile("tableau-de-bord").setTitle("Mes devis · " + NOM_PRO)
    .addMetaTag("viewport", "width=device-width, initial-scale=1");
}

function donneesTableau() {
  const ss = ss_(), tz = Session.getScriptTimeZone();
  const f = ss.getSheetByName(ONGLET), n = Math.max(f.getLastRow() - 4, 0);
  const lignes = n ? f.getRange(5, 1, n, ENTETES.length).getValues().filter(l => l[C["N° devis"]]) : [];
  const jour = d => d instanceof Date ? Utilities.formatDate(d, tz, "dd/MM") : "";
  const auj = new Date(); auj.setHours(0, 0, 0, 0);
  const debutMois = new Date(auj.getFullYear(), auj.getMonth(), 1);
  const k = { encaisse: 0, nbPaiements: 0, attente: 0, nbAttente: 0, reste: 0, nbReste: 0, nbSignes: 0, nbTotal: lignes.length, objectif: OBJECTIF_MOIS };
  const todo = [], parEmail = {};
  const eur = x => Math.round(x).toLocaleString("fr-FR") + " €";
  lignes.forEach(l => {
    const st = String(l[C["Statut"]]), mt = Number(l[C["Montant"]]) || 0, enc = Number(l[C["Encaissé"]]) || 0;
    const num = String(l[C["N° devis"]]), cli = String(l[C["Client"]]), pay = String(l[C["Paiement"]] || "");
    const email = String(l[C["Email"]]).replace(/^.*<|>.*$/g, "").trim().toLowerCase();
    parEmail[email] = (parEmail[email] || 0) + 1;
    if (l[C["Payé le"]] instanceof Date && l[C["Payé le"]] >= debutMois) { k.encaisse += enc; k.nbPaiements++; }
    if (st === "En attente" || st === "Répondu") { k.attente += mt; k.nbAttente++; }
    if (st === "Signé") { k.nbSignes++; if (pay !== "Payé en entier") { k.reste += mt - enc; k.nbReste++; } }
    const fin = l[C["Valable jusqu'au"]];
    if (st === "Répondu") todo.push({ num, p: 1, ic: "✉", fond: "#E6EEFF", coul: "#2A4FA8", titre: cli + " t'a répondu", detail: num + " · les relances sont arrêtées", act: "gmail", bouton: "Répondre" });
    if ((st === "En attente" || st === "Répondu") && fin instanceof Date) {
      const j = Math.round((fin - auj) / 864e5);
      if (j >= 0 && j <= 5) todo.push({ num, p: 2, ic: "!", fond: "#FFF3D6", coul: "#8A5A00", titre: cli + " : devis valable encore " + j + " jour" + (j > 1 ? "s" : ""), detail: num + " · " + eur(mt) + " · un appel peut faire la différence", act: "tel", bouton: "Appeler" });
    }
    if (l[C["Payé le"]] instanceof Date && (auj - l[C["Payé le"]]) < 864e5 * 2) todo.push({ num, p: 3, ic: "€", fond: "#E3F4EA", coul: "#1D6B41", titre: cli + " a payé " + eur(enc), detail: pay + " · " + num, act: "fiche", bouton: "Voir" });
    const env = l[C["Envoyé le"]];
    if (st === "Signé" && pay === "Lien envoyé" && env instanceof Date && (auj - env) > 864e5 * 7) todo.push({ num, p: 4, ic: "⏳", fond: "#FDEBE7", coul: "#9A3412", titre: cli + " n'a pas encore réglé l'acompte", detail: num + " · signé, lien de paiement envoyé", act: "gmail", bouton: "Écrire" });
    if (st === "En attente" && [l[C["Relance 1"]], l[C["Relance 2"]]].some(r => r instanceof Date && r >= auj)) todo.push({ num, p: 5, ic: "↻", fond: "#EFEDE8", coul: "#4A4741", titre: "Relance envoyée à " + cli, detail: num + " · ce matin, automatiquement", act: "fiche", bouton: "Voir" });
  });
  todo.sort((a, b) => a.p - b.p);
  k.taux = k.nbTotal ? Math.round(k.nbSignes / k.nbTotal * 100) : 0;
  const c = clients_(ss), nc = Math.max(c.getLastRow() - 1, 0);
  const clients = nc ? c.getRange(2, 1, nc, 4).getValues().filter(r => r[0] || r[1]).map(r => ({ nom: String(r[0]), email: String(r[1]), tel: String(r[2]), adresse: String(r[3]), devis: parEmail[String(r[1]).trim().toLowerCase()] || 0 })) : [];
  const detail = t => { try { return t ? JSON.parse(t) : null; } catch (e) { return null; } };
  return { nom: NOM_PRO, couleur: COULEUR, accent: ACCENT, tva: TAUX_TVA, acompte: ACOMPTE_POURCENT, relances: RELANCES, moi: Session.getEffectiveUser().getEmail(), signature: LIEN_SIGNATURE,
    maj: Utilities.formatDate(new Date(), tz, "'le' dd/MM 'à' HH'h'mm"), kpis: k, todo: todo.slice(0, 8),
    devis: lignes.reverse().map(l => ({ num: String(l[C["N° devis"]]), client: String(l[C["Client"]]), email: String(l[C["Email"]]).replace(/^.*<|>.*$/g, "").trim(),
      montant: Number(l[C["Montant"]]) || 0, envoye: jour(l[C["Envoyé le"]]), fin: jour(l[C["Valable jusqu'au"]]), r1: jour(l[C["Relance 1"]]), r2: jour(l[C["Relance 2"]]),
      statut: String(l[C["Statut"]] || "En attente"), paiement: String(l[C["Paiement"]] || ""), encaisse: Number(l[C["Encaissé"]]) || 0, payeLe: jour(l[C["Payé le"]]),
      payeMois: l[C["Payé le"]] instanceof Date && l[C["Payé le"]] >= debutMois, fil: String(l[C["Fil Gmail"]] || ""), detail: detail(l[C["Détail"]]) })), clients };
}

// ---------- Actions de la fiche devis ----------
function trouver_(num) {
  const f = ss_().getSheetByName(ONGLET), n = f.getLastRow() - 4;
  const nums = n > 0 ? f.getRange(5, 1, n, 1).getValues().map(r => String(r[0])) : [];
  const i = nums.indexOf(String(num));
  if (i < 0) throw new Error("Devis " + num + " introuvable dans ton tableau.");
  return { f, ligne: i + 5, l: f.getRange(i + 5, 1, 1, ENTETES.length).getValues()[0] };
}

// PDF du devis : la pièce jointe du premier mail envoyé.
function pdfDevis(num) {
  const t = trouver_(num), fil = t.l[C["Fil Gmail"]] && GmailApp.getThreadById(String(t.l[C["Fil Gmail"]]));
  if (!fil) throw new Error("Mail du devis introuvable dans ton Gmail.");
  const pj = fil.getMessages()[0].getAttachments().find(a => /pdf/i.test(a.getContentType()));
  if (!pj) throw new Error("Pas de PDF joint au mail de ce devis.");
  return { nom: pj.getName(), pdf: Utilities.base64Encode(pj.getBytes()) };
}

// Statut choisi à la main : Signé, Refusé, Pause, En attente.
function changerStatut(num, statut) {
  if (STATUTS.indexOf(statut) < 0) throw new Error("Statut inconnu.");
  const t = trouver_(num);
  t.f.getRange(t.ligne, C["Statut"] + 1).setValue(statut);
  return donneesTableau();
}

// Paiement reçu en dehors du lien (virement, espèces, chèque…).
function marquerPaye(num, montant) {
  const t = trouver_(num), total = Number(t.l[C["Montant"]]) || 0;
  const enc = Math.round(((Number(t.l[C["Encaissé"]]) || 0) + Number(montant)) * 100) / 100;
  if (!(Number(montant) > 0)) throw new Error("Indique le montant reçu.");
  t.f.getRange(t.ligne, C["Statut"] + 1).setValue("Signé");
  t.f.getRange(t.ligne, C["Paiement"] + 1).setValue(enc >= total - 0.01 ? "Payé en entier" : "Acompte payé");
  t.f.getRange(t.ligne, C["Encaissé"] + 1).setValue(enc);
  t.f.getRange(t.ligne, C["Payé le"] + 1).setValue(new Date());
  return donneesTableau();
}

// Relance tout de suite (même texte que la relance automatique suivante), dans le fil du devis.
function relancerMaintenant(num) {
  const t = trouver_(num), l = t.l, fil = l[C["Fil Gmail"]] && GmailApp.getThreadById(String(l[C["Fil Gmail"]]));
  if (!fil) throw new Error("Mail du devis introuvable dans ton Gmail.");
  const fin = l[C["Valable jusqu'au"]] instanceof Date ? l[C["Valable jusqu'au"]] : null;
  const vars = { prenom: String(l[C["Client"]]).split(" ")[0], numero: num, signature: SIGNATURE,
    validite: fin ? Utilities.formatDate(fin, Session.getScriptTimeZone(), "dd/MM/yyyy") : "" };
  const deuxieme = !!l[C["Relance 1"]];
  if (deuxieme && l[C["Relance 2"]]) throw new Error("Les 2 relances sont déjà parties : un appel sera plus efficace.");
  repondre_(fil, remplir_(deuxieme ? TEXTE_RELANCE_2 : TEXTE_RELANCE_1, vars));
  t.f.getRange(t.ligne, C[deuxieme ? "Relance 2" : "Relance 1"] + 1).setValue(new Date());
  return donneesTableau();
}

// Import d'une liste CSV venue d'un autre outil : repère tout seul les colonnes nom, email, téléphone, adresse.
function importerCsv(texte) {
  const sep = (texte.split("\n")[0].match(/;/g) || []).length > (texte.split("\n")[0].match(/,/g) || []).length ? ";" : ",";
  const t = Utilities.parseCsv(texte.replace(/^\uFEFF/, ""), sep);
  if (t.length < 2) return 0;
  const h = t[0].map(x => String(x).toLowerCase());
  const col = mots => h.findIndex(x => mots.some(m => x.indexOf(m) >= 0));
  const iMail = col(["mail", "e-mail", "courriel"]), iTel = col(["tél", "tel", "phone", "portable", "mobile"]);
  const iAdr = col(["adresse", "address", "ville"]), iNom = col(["nom complet", "full name", "name", "nom", "client"]), iPre = col(["prénom", "prenom", "first"]);
  let n = 0;
  t.slice(1).forEach(r => {
    const nom = [iPre >= 0 && iPre !== iNom ? r[iPre] : "", iNom >= 0 ? r[iNom] : ""].join(" ").trim();
    if (ajouterClient_(nom, iMail >= 0 ? r[iMail] : "", iTel >= 0 ? r[iTel] : "", iAdr >= 0 ? r[iAdr] : "", "Importé")) n++;
  });
  return n;
}

// Import des contacts Google (ceux de ton Gmail). Il faut ajouter une fois le service « People API » dans Apps Script.
function importerContactsGoogle() {
  if (typeof People === "undefined") throw new Error("Dans Apps Script : Services (+) > People API > Ajouter, puis réessaie.");
  let page, n = 0;
  do {
    const r = People.People.Connections.list("people/me", { personFields: "names,emailAddresses,phoneNumbers,addresses", pageSize: 1000, pageToken: page });
    (r.connections || []).forEach(p => {
      const g = (a, k) => (a && a[0] && a[0][k]) || "";
      if (ajouterClient_(g(p.names, "displayName"), g(p.emailAddresses, "value"), g(p.phoneNumbers, "value"), g(p.addresses, "formattedValue"), "Contact Google")) n++;
    });
    page = r.nextPageToken;
  } while (page);
  return n;
}

// ---------- Nouveau devis depuis le tableau de bord ----------
// Onglet « Tarifs » : tes prestations et tes prix (rempli par l'assistante à l'installation).
const ONGLET_TARIFS = "Tarifs";
function tarifs_(ss) {
  let t = ss.getSheetByName(ONGLET_TARIFS);
  if (!t) {
    t = ss.insertSheet(ONGLET_TARIFS);
    t.getRange(1, 1, 1, 3).setValues([["Prestation", "Prix unitaire", "Unité"]]).setFontWeight("bold").setBackground("#161616").setFontColor("#ffffff");
    t.setFrozenRows(1); t.setColumnWidth(1, 280);
    t.getRange("B2:B").setNumberFormat('#,##0.00 "€"');
  }
  return t;
}

function listeTarifs() {
  const t = tarifs_(ss_()), n = t.getLastRow() - 1;
  return n > 0 ? t.getRange(2, 1, n, 3).getValues().filter(r => r[0]).map(r => ({ lib: String(r[0]), pu: Number(r[1]) || 0, unite: String(r[2] || "") })) : [];
}

function prochainNumero_() {
  const f = ss_().getSheetByName(ONGLET), n = f.getLastRow() - 4, an = new Date().getFullYear();
  let max = 0;
  if (n > 0) f.getRange(5, 1, n, 1).getValues().forEach(r => { const m = String(r[0]).match(/^D-(\d{4})-(\d+)$/); if (m && Number(m[1]) === an) max = Math.max(max, Number(m[2])); });
  return "D-" + an + "-" + String(max + 1).padStart(3, "0");
}

// d = { nom, email, adresse, projet, lignes: [{ lib, qte, pu }] }
function creerDevis(d) {
  const lignes = (d.lignes || []).filter(l => l.lib && Number(l.qte) > 0).map(l => ({ lib: String(l.lib), qte: Number(l.qte), pu: Math.round(Number(l.pu) * 100) / 100 }));
  if (!d.nom || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email || "")) throw new Error("Il manque le nom ou l'email du client.");
  if (!lignes.length) throw new Error("Ajoute au moins une ligne.");
  const tz = Session.getScriptTimeZone(), num = prochainNumero_();
  const ht = lignes.reduce((s, l) => s + l.qte * l.pu, 0), tva = Math.round(ht * TAUX_TVA) / 100, ttc = ht + tva;
  const acompte = ACOMPTE_POURCENT > 0 ? Math.round(ttc * ACOMPTE_POURCENT) / 100 : 0;
  const auj = new Date(), fin = new Date(); fin.setDate(fin.getDate() + VALIDITE_JOURS);
  const eur = x => x.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";
  const jour = x => Utilities.formatDate(x, tz, "dd/MM/yyyy"), e = s => echapper_(String(s || ""));
  const html = '<html><head><meta charset="utf-8"><style>body{font-family:Helvetica,Arial,sans-serif;color:#161616;font-size:11pt;margin:28px}' +
    'h1{font-size:22pt;margin:0;color:' + COULEUR + '}.bande{height:6px;background:' + COULEUR + ';margin:10px 0 18px}' +
    'table{width:100%;border-collapse:collapse}th{background:' + COULEUR + ';color:#fff;text-align:left;padding:7px;font-size:10pt}td{padding:7px;border-bottom:1px solid #ddd}' +
    '.r{text-align:right}.tot td{border:0;padding:4px 7px}.big{font-size:13pt;font-weight:bold}.projet{background:#f4f2ec;border-left:4px solid ' + ACCENT + ';padding:10px 12px;margin:14px 0}' +
    '.p{font-size:9pt;color:#555;margin-top:18px}.acc{border:1px solid #bbb;padding:12px;margin-top:18px;height:70px}</style></head><body>' +
    '<table><tr><td style="border:0;padding:0"><h1>DEVIS</h1><b>' + num + '</b><br>Date : ' + jour(auj) + '<br>Valable jusqu\'au ' + jour(fin) + '</td>' +
    '<td style="border:0;padding:0" class="r"><b>' + e(NOM_PRO) + '</b><br>' + e(ADRESSE_PRO).replace(/\n|&lt;br&gt;/g, "<br>") + '<br>SIRET ' + e(SIRET) + '<br>' + e(Session.getEffectiveUser().getEmail()) + '</td></tr></table>' +
    '<div class="bande"></div><b>Pour :</b> ' + e(d.nom) + '<br>' + e(d.adresse).replace(/<br>/g, ", ") + (d.adresse ? '<br>' : '') + e(d.email) +
    (d.projet ? '<div class="projet"><b>Votre projet</b><br>' + e(d.projet) + '</div>' : '<br><br>') +
    '<table><tr><th>Désignation</th><th class="r">Qté</th><th class="r">Prix unitaire' + (TAUX_TVA ? ' HT' : '') + '</th><th class="r">Total' + (TAUX_TVA ? ' HT' : '') + '</th></tr>' +
    lignes.map(l => '<tr><td>' + e(l.lib) + '</td><td class="r">' + l.qte + '</td><td class="r">' + eur(l.pu) + '</td><td class="r">' + eur(l.qte * l.pu) + '</td></tr>').join('') + '</table>' +
    '<table class="tot" style="width:55%;margin-left:45%;margin-top:8px">' +
    (TAUX_TVA ? '<tr><td>Total HT</td><td class="r">' + eur(ht) + '</td></tr><tr><td>TVA ' + TAUX_TVA + ' %</td><td class="r">' + eur(tva) + '</td></tr><tr class="big"><td>Total TTC</td><td class="r">' + eur(ttc) + '</td></tr>'
      : '<tr class="big"><td>Net à payer</td><td class="r">' + eur(ttc) + '</td></tr><tr><td colspan="2" style="font-size:9pt">' + e(MENTION_TVA) + '</td></tr>') +
    (acompte ? '<tr><td>Acompte à la signature (' + ACOMPTE_POURCENT + ' %)</td><td class="r">' + eur(acompte) + '</td></tr>' : '') + '</table>' +
    '<p class="p">Devis gratuit. Conditions de paiement : ' + (acompte ? 'acompte de ' + ACOMPTE_POURCENT + ' % à la signature, solde à la fin de la prestation' : 'à la fin de la prestation') +
    '. En cas de retard de paiement : pénalités au taux légal et, pour les professionnels, indemnité forfaitaire de 40 € pour frais de recouvrement.</p>' +
    '<div class="acc">Bon pour accord, date et signature :</div></body></html>';
  const pdf = Utilities.newBlob(html, MimeType.HTML, num + ".html").getAs(MimeType.PDF).setName("Devis " + num + ".pdf");
  const prenom = String(d.nom).split(" ")[0];
  const objet = "Devis " + num + " · " + d.nom + " · " + Math.round(ttc).toLocaleString("fr-FR") + " €";
  const texte = remplir_(TEXTE_ENVOI, { prenom, numero: num, total: eur(ttc), validite: jour(fin), signature: SIGNATURE });
  const msg = GmailApp.createDraft(d.email, objet, texte, { htmlBody: echapper_(texte), attachments: [pdf], name: NOM_PRO }).send();
  const f = ss_().getSheetByName(ONGLET), ligne = ENTETES.map(() => "");
  ligne[C["N° devis"]] = num; ligne[C["Client"]] = d.nom; ligne[C["Email"]] = d.email; ligne[C["Montant"]] = ttc;
  ligne[C["Envoyé le"]] = auj; ligne[C["Valable jusqu'au"]] = fin; ligne[C["Statut"]] = "En attente"; ligne[C["Fil Gmail"]] = msg.getThread().getId();
  ligne[C["Détail"]] = JSON.stringify({ adresse: d.adresse || "", projet: d.projet || "", lignes });
  f.appendRow(ligne);
  ajouterClient_(d.nom, d.email, "", d.adresse || "", "Ajouté avec le devis " + num);
  return { num, total: eur(ttc), pdf: Utilities.base64Encode(pdf.getBytes()) };
}

// ---------- Outils ----------
function remplir_(texte, v) { return texte.replace(/{(\w+)}/g, (x, k) => (k in v ? v[k] : x)); }
function echapper_(t) { return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, "<br>"); }
function bouton_(texte, url, plein) {
  return '<a href="' + url + '" style="display:inline-block;padding:12px 20px;border-radius:999px;font-weight:700;text-decoration:none;' +
    (plein ? 'background:#161616;color:#ffffff' : 'border:2px solid #161616;color:#161616') + '">' + texte + '</a>';
}
// Répond au client avec le même objet (« Re: ... »), depuis ton adresse.
function repondre_(fil, texte) {
  const premier = fil.getMessages()[0];
  GmailApp.sendEmail(premier.getTo(), "Re: " + premier.getSubject(), texte, { htmlBody: echapper_(texte), name: NOM_PRO });
}
