# Factures : les règles (service-public F23208, vérifié le 07/08/2026 ; actualité A18953 du 02/09/2026)

## Mentions obligatoires (relire F23208 en cas de doute)
- Date d'émission ; numéro unique, d'une suite continue et sans trou (sur chaque page si plusieurs pages).
- Date de la vente ou de la prestation.
- Vendeur : nom et prénom + « Entrepreneur individuel » ou « EI » (si EI), adresse, SIREN (ou « Siret en cours d'attribution »).
- Client : nom, adresse ; client pro : son numéro de TVA s'il en a un (sauf facture de 150 € HT ou moins).
- Numéro du bon de commande s'il y en a un.
- Pour chaque ligne : désignation, quantité, prix unitaire HT, taux de TVA (ou mention d'exonération) ; totaux HT et TTC ; remises.
- Date d'échéance du paiement ; conditions d'escompte ou « Escompte pour paiement anticipé : néant ».
- Client pro : taux des pénalités de retard et indemnité forfaitaire de 40 € pour frais de recouvrement.
- Franchise de TVA : la mention de franchise (voir mentions-legales.md, elle change de référence : vérifier la date exacte de bascule sur impots.gouv.fr au moment de facturer).

## Quand faire une facture
- En principe à la livraison ou à la fin de la prestation.
- Client particulier, prestation de services : obligatoire au-delà de 25 € TTC, ou si le client la demande.
- Conservation : 10 ans.

## Corriger une facture
- Jamais de modification d'une facture déjà émise.
- Avant paiement : facture rectificative « Annule et remplace la facture n° … », avec un nouveau numéro.
- Après paiement : facture d'avoir.

## Facture électronique (clients professionnels français)
- Depuis le 01/09/2026 : toutes les entreprises assujetties à la TVA doivent pouvoir RECEVOIR des factures électroniques.
- ÉMETTRE en facture électronique : PME et micro-entreprises à partir du 01/09/2027 (via une plateforme agréée ou une solution raccordée à une plateforme agréée).
- Clients particuliers et clients étrangers : pas de facture électronique, mais déclaration des ventes (e-reporting) selon le calendrier officiel.
- À ce moment-là, le modèle HTML du kit reste utile pour les particuliers ; pour les pros, il faudra passer par une plateforme agréée.

## Sanctions (F23208)
- Mention manquante ou fausse : 15 € par omission, plafonné à 25 % du montant de la facture.
