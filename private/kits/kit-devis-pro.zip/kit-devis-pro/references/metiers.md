# Repères par métier

Pour proposer des lignes de devis et le bon encadré « Votre projet ». Ce sont des exemples : n'utilise que les prix de la personne.

| Métier | Lignes typiques | Points d'attention |
|---|---|---|
| Graphiste, webdesigner | Atelier de cadrage, création (logo, charte, site), allers-retours de corrections, fichiers sources, cession de droits | Écrire le nombre de corrections compris et ce qui est facturé en plus. Préciser la cession de droits (supports, durée, territoire). |
| Photographe, vidéaste | Séance (durée), déplacement, retouches (nombre de photos), livraison (galerie, délai), droits d'usage | Nombre de photos livrées, délai de livraison, usage commercial ou privé. |
| Rédacteur, community manager | Audit, stratégie, nombre de publications/articles par mois, réunions, rapport | Durée d'engagement, préavis, ce qui n'est pas compris (pub payante, shooting). |
| Consultant, coach, formateur | Diagnostic, séances (nombre × durée), supports, suivi entre les séances | Formation pro : vérifier si la personne est organisme de formation (convention de formation à la place du devis). Coach : ne jamais promettre un résultat. |
| Artisan du bâtiment, dépannage | Main-d'œuvre (taux horaire TTC + décompte), fournitures (quantité, prix unitaire), déplacement, évacuation des déchets | Devis obligatoire et mentions en plus (voir mentions-legales.md, section 6). Assurance décennale. |
| Beauté, bien-être (à domicile ou en institut) | Prestation, forfait mariage/événement, essai, déplacement | Devis surtout pour les événements et les forfaits. Acompte ou arrhes à préciser. |
| Traiteur, pâtissier, événementiel | Nombre de personnes × prix, matériel, livraison, service | Date limite pour confirmer le nombre de personnes. Acompte. |
| Assistante virtuelle, freelance admin | Forfait d'heures par mois, tâches comprises, heures en plus | Report ou non des heures non utilisées. |

Si le métier n'est pas dans la liste : propose des lignes à partir des prestations de la fiche, et demande à la personne de valider.
