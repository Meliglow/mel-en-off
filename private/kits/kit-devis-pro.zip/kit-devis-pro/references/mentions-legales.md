# Mentions à mettre sur un devis (France)

Vérifié le 25/11/2026 sur entreprendre.service-public.gouv.fr (fiches F31144 et F23211), impots.gouv.fr et service-public.gouv.fr (actualité A15398). Les taux changent chaque semestre : si tu peux faire une recherche, vérifie les taux du semestre en cours avant de les écrire.

## 1. Sur tous les devis (socle)
- Le mot « Devis », un numéro unique qui se suit, la date du devis.
- La durée de validité de l'offre (ex. « Devis valable 30 jours », avec la date de fin).
- L'émetteur : nom ou dénomination, forme juridique, adresse, SIRET. Société : capital et RCS. Artisan : immatriculation au registre. TVA facturée : numéro de TVA intracommunautaire.
- Le client : nom, adresse (lieu d'exécution si différent). Client professionnel : son SIREN.
- Le détail : désignation précise de chaque prestation, quantité, unité, prix unitaire HT.
- Les totaux : total HT, taux et montant de TVA, total TTC.
- Frais de déplacement s'il y en a.
- Date de début prévue et durée estimée de la prestation.
- Conditions de paiement : montant de l'acompte, échéances, délai, moyens de paiement.
- Si le devis est gratuit ou payant (et son prix s'il est payant).
- Zone d'accord : « Bon pour accord », date, nom, signature. Le client n'est engagé par le devis qu'à partir du moment où il le signe (service-public, F31144).

## 2. Franchise de TVA (micro-entreprise qui ne facture pas la TVA)
- Pas de TVA sur le document. Le total s'appelle « Net à payer » ou « Total ».
- Mention, jusqu'au 31/12/2026 : « TVA non applicable, article 293 B du Code général des impôts (CGI) ».
- Mention à partir du 01/01/2027 : « TVA non applicable, article L. 223-3 du Code des impositions des biens et des services (CIBS) ».
- Source : impots.gouv.fr (page modifiée le 14/10/2026). La page parle des factures ; la mettre aussi sur le devis est l'usage, pour que le client sache que le prix est sans TVA.

## 3. Acompte ou arrhes : à écrire clairement
- « Si rien n'est indiqué, la somme versée sera considérée comme étant des arrhes » (service-public, F31144).
- Arrhes : chacun peut se dédire (le client perd les arrhes ; si c'est le pro qui annule, il rend le double).
- Acompte : engagement ferme des deux côtés.
- Écris donc : « Acompte de X € (Y %) à la signature » ou « Arrhes de X € ».

## 4. Client professionnel : paiement et retards (F23211 et A15398)
- Délai de paiement par défaut : 30 jours après la réalisation de la prestation. Possible par accord : 45 jours fin de mois ou 60 jours à compter de la date de la facture.
- Pénalités de retard : taux à écrire dans les conditions. Minimum légal : 3 fois le taux d'intérêt légal (professionnels, 2e semestre 2026 : 2,75 % × 3 = 8,25 %). Sans taux prévu, c'est le taux de la BCE majoré de 10 points (12,40 % au 2e semestre 2026).
- Indemnité forfaitaire pour frais de recouvrement : 40 €, à mentionner.
- Formule type : « En cas de retard de paiement, pénalités au taux de [X] % par an et indemnité forfaitaire pour frais de recouvrement de 40 € (art. L.441-10 du Code de commerce). Pas d'escompte pour paiement anticipé. »

## 5. Client particulier
- Les pénalités minimales et les 40 € ci-dessus concernent les clients professionnels. Pour un particulier, ne les écris pas.
- Démarchage (devis signé chez le client ou hors de ton local) : le client a 14 jours pour se rétracter (F31144). Le signaler sur le devis dans ce cas.

## 6. Métiers où le devis est obligatoire, avec des mentions en plus (F31144)
- Bâtiment et dépannage : lieu d'exécution, nature exacte des travaux, décompte détaillé (quantité, prix unitaire), taux horaire de main-d'œuvre TTC, modalités de décompte du temps, frais de déplacement. Mentionner l'assurance professionnelle obligatoire (ex. décennale : assureur, couverture géographique).
- Services à la personne : devis gratuit et obligatoire dès 100 € TTC par mois (ou si le client le demande) ; numéro d'agrément ou de déclaration, mode d'intervention, nombre d'heures, prix horaire ou forfaitaire.
- Déménagement, location de voiture, optique et audition, perte d'autonomie, chirurgie esthétique : devis obligatoire et gratuit, avec des règles propres. Dis à la personne de vérifier la fiche F31144 de service-public pour son métier.
- Sanction en cas de manquement : amende jusqu'à 3 000 € (personne physique) ou 15 000 € (société) (F31144).

## 7. Ce qui ne change PAS pour le devis
- La facture électronique (réforme en cours en France) concerne les factures entre entreprises, pas les devis. Au moment de transformer un devis en facture, vérifie les règles de facturation en vigueur à cette date.

## Note du 26/11/2026 : date de la nouvelle mention de franchise
Les sources officielles ne disent pas exactement la même chose :
- impots.gouv.fr (lu le 25/11/2026) : « article L. 223-3 du CIBS » à partir du 01/01/2027.
- service-public F23208 (vérifié le 07/08/2026, lu en résumé) : nouvelle mention (« art. L. 223 et s. du CIBS ») depuis le 01/09/2026, l'ancienne (293 B) tolérée jusqu'au 31/12/2027.
Règle du kit, valable dans les deux cas : jusqu'au 31/12/2026, « TVA non applicable, article 293 B du CGI » ; à partir du 01/01/2027, la nouvelle mention CIBS. Si la personne le demande, propose de vérifier la page impots.gouv.fr du jour.
